## Deploying
You can [run the preview app locally](running-locally.md) or deploy it straight to a Heroku instance.

An existing Heroku instance can be found at: [http://idsk-review.herokuapp.com/](http://idsk-review.herokuapp.com/)
