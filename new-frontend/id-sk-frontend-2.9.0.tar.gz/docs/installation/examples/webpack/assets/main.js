import Button from 'govuk-frontend/components/button/button'

new Button(document).init()
