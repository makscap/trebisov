# Code of Conduct

This project follows the 'alphagov' Github organisation's Code of Conduct (https://github.com/alphagov/code-of-conduct).
